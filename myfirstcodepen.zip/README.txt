A Pen created at CodePen.io. You can find this one at http://codepen.io/120hit/pen/GqKJpZ.

 This is just a scratch model, I'm still in the learning phase  